
 WaterAndSky(Sun).tif + WaterAndSky(Moon).tif:

  Both screenshots are taken at the same time
  with different directions of view. So you can
  see that the skydome is able to calculate
  different colors dependent on the sun position.
  You can also see the exact per-pixel lighting
  of the moon (nearly a complete full moon).
  Also the most important water features are
  visible: fresnel reflection for each ripple
  and wave; reflections and refractions are bumped
  contrarotated; alpha fading at the water's edge
  and depth dependent color filtering for the
  refraction map. 