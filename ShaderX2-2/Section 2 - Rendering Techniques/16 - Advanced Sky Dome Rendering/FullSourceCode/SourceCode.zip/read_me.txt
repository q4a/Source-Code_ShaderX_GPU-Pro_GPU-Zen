
 To be able to run the release or debug build executables (.exe)
   you must
     copy the complete 'Media'-folder (..\Demo-Modules\Demos\Media)
     to your release or debug build path (..\Release\Media or ..\Debug\Media)
   or
     copy the executable (.exe) to ..\Demo-Modules\Demos.

 To be able to start the release or debug build within the demo browser
   you must
     copy the executable (.exe) to ..\Demo-Modules\Demos and rename
     the exe-file:
       Waterdemo.exe   -> Water.demo
       Skydomedemo.exe -> Skydome.demo

----------------------------------------------------------------------------------
  Whilst every care has been taken in preparation of the browser
  and the demo modules, the authors accepts no responsibility for
  any consequences of its use.