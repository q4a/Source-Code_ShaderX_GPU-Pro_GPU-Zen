/*****************************************************************************
  Name : "D3DVoxel.cpp"
  Date : April 2003

  $Revision: 1.6 $
  
  <name>.cpp is an example of a scene to be used with D3DShell. 
  Make sure your application include D3DShell.h to have access to D3DShell 
  functions.

  D3DShell is a program used to make D3D programming easier and less 
  time-consuming. D3DShell takes care of all Direct3D initialisation for the 
  user : handling D3D devices, Fullscreen mode, resolution mode, window modes, 
  buffering modes, Z-Buffer use, viewport creation, viewport clearing, etc...

  Six basic functions have to exist in the scene file to interact correctly with 
  D3DShell. A list of these functions is :

  
  **********************************************************************************
  * void InitApplication(HINSTANCE hInstance, HWND hWindow, char *pszCommandLine); *
  **********************************************************************************

  This function will be called by D3DShell ONCE at the beginning of the D3DShell 
  WinMain() function. This function enables the user to perform any initialisation 
  before any 3D is rendered.
  The application instance and window handle are passed to this function so that the 
  programmer can use them should they needs those.
  From this function the user may call D3DShellSetPreferences() to :
  - Specify the application name.
  - Submit a menu and/or an accelerator table.
  - Specify the icon used for the application.
  - Adjust the behaviour of the application by specifying some flags.

  A prototype of the function is :
	
	void D3DShellSetPreferences(const char		*pszApplicationName, 
								const HMENU		hUserMenuID, 
								const HACCEL	hUserAccel,
								const HICON		hUserIcon, 
								const DWORD		dwFlags);

  A list of flags and their functions can be found in the D3DShell.h file.


  **************************
  * void QuitApplication() *
  **************************

  This function will be called by the D3D Shell just before finishing the program.
  It enables the user to release any memory allocated before.
  

  ******************************************************************************
  * void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) *
  ******************************************************************************

  This function is the user Window Procedure function. It enables the user to retrieve
  menu choices, keystrokes or other messages (WM_TIMER for instance).
  
  D3DShell processes many window messages. If the user needs to 
  process these messages in their application, they should make sure
  NOT to return DefWindowProc() as it will prevent D3DShell WindowProc
  to do its own processing for these messages.
  The window messages processed by D3DShell are :

  WM_ENTERMENULOOP, WM_EXITMENULOOP,
  WM_ACTIVATEAPP,
  WM_SYSCOMMAND,
  WM_SIZE, WM_MOVE, WM_SIZING, WM_MOVING,
  WM_PAINT,
  WM_DESTROY, WM_QUIT

  Note : There are some keys already used by D3DShell as accelerators. You should not
		 remap these keys, as the related functions will not work anymore in that case.
		 The list of keys used by D3DShell is : F4, F5, F6, F12, Alt+ENTER.


  **********************************************
  * BOOL RenderScene(LPDIRECT3DDEVICE9 lpDev9) *
  **********************************************

  This is the main user function in which you have to do your own rendering.
  A pointer to the D3D device (LPDIRECT3DDEVICE9) is passed to this function 
  so you can use it to control your rendering (Renderstates, lights, etc...)
  This function is called every frame by D3DShell and enable the user to
  create the scene for this frame.
  

  ************************************************************************************
  * BOOL InitView(LPDIRECT3D9 lpD3D9, LPDIRECT3DDEVICE9 lpDev9,						 *
  *				  DWORD dwWidth, DWORD dwHeight)									 *
  ************************************************************************************

  This function enables the user to create vertex buffers, materials, set 
  rendering values, load textures, etc... This function will be called each 
  time the surfaces and objects will be recreated (i.e. when a rendering
  variable is changed).
  dwWidth and dwHeight are the current dimensions of the rendering surface.


  **********************
  * void ReleaseView() *
  **********************

  This function enables the user to release any devices they created 
  in the InitView function.
  The function will be called each time a rendering variable is changed.

  
  BUILD INFORMATION:
  ------------------

  Source files :	D3DShell.cpp + D3DShell.h + "Scene file".cpp
  Libraries :		D3D9.LIB + D3DX9.LIB

  
  For more information concerning D3DShell, please read D3DShell.txt.

  Copyright : 2003 by PowerVR Technologies. All rights reserved.
******************************************************************************/

#include <d3dx9.h>
#include <crtdbg.h>

#include "D3DShell.h"	/* D3DShell header */
#include "D3DTools.h"	/* D3DTools header */

#include "resource.h"


/****************************************************************************
** Build options
****************************************************************************/
#ifdef _DEBUG
#undef ENABLE_FINAL_QUALITY_RENDER
#else
#define ENABLE_FINAL_QUALITY_RENDER
#endif

#undef ENABLE_USER_CONTROL

/****************************************************************************
** Defines
****************************************************************************/
#define FILE_VS			((char*)"voxel.vsh")
#define FILE_PS_HOLO	((char*)"voxel_holo.psh")
#define FILE_PS_SOLID	((char*)"voxel_solid.psh")
#define FILE_PS_LIT1	((char*)"voxel_lit_aura_1.psh")
#define FILE_PS_LIT3	((char*)"voxel_lit_aura_3.psh")

#define FILE_TX_TEST	((char*)"vol.dds")
#define FILE_TX_TEST_A	((char*)"vol-a.dds")
#define FILE_TX_HEAD_A	((char*)"StanfordMRbrain_256x256x128_A8.dds")
#define FILE_TX_BUNNY_A	((char*)"StanfordCTBunny_128x128x128_A8.dds")
#define FILE_TX_LOGO	((char*)"LogoPVR.bmp")

#define CAM_FOV_Y	(35.0f * D3DX_PI / 180.0f)
#define CAM_ASPECT	(4.0f / 3.0f)
#define CAM_NEAR	(1.0f)
#define CAM_FAR		(100.0f)

#ifdef ENABLE_FINAL_QUALITY_RENDER
#define TX_SIZE_METABALL	64
#define NUM_STEPS_SHIFT		0
#define FILTERING			D3DTEXF_LINEAR
#define ANIM_FPF			100
#else
#define TX_SIZE_METABALL	32
#define NUM_STEPS_SHIFT		2
#define FILTERING			D3DTEXF_POINT
#define ANIM_FPF			8
#endif

#define METABALL_NUM			(8)
#define METABALL_KEYFRAME_NUM	(9)

#define METABALL_FRAME_CNT		((METABALL_KEYFRAME_NUM-1) * ANIM_FPF)

#define CLIP_NUM			(sizeof(g_psAnimLoop) / sizeof(*g_psAnimLoop))

/****************************************************************************
** Enums
****************************************************************************/
enum ERenderType { eHolo, eSolid, eLit1, eLit3 };
enum ERenderOb { eTest, eMetaballs, eHead, eBunny };

/****************************************************************************
** Structures
****************************************************************************/
struct SVtx
{
	float	x, y, z;
	float	u, v, w;
};

struct SCamera
{
	float		fX, fY;
	D3DVECTOR	vFrom, vTo;
};

struct SAnimLoop
{
	ERenderType	eRenderType;
	ERenderOb	eRenderOb;
	DWORD		dwNumSteps;				// Number of steps to take through the volume
	union
	{
		float		fThreshold;			// Threshold value to detect matter
		float		fBrightnessScale;	// Scale the brightness for holo rendering
	};
	BOOL		bAnimateThresholdValue;
	float		fRotX;					// Rotation around X to apply
};

/****************************************************************************
** Declarations
****************************************************************************/
static BOOL LoadShaders();

#ifdef ENABLE_USER_CONTROL
static void UserInput(void);
#endif // ENABLE_USER_CONTROL

// callbacks for D3DXFillVolumeTexture()
VOID WINAPI FillTxVolMb(D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData);
VOID WINAPI FillTxVolMbA(D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData);

static void CalcMbPos(
	D3DVECTOR		* const pvOut,
	const D3DVECTOR * const pv0,
	const D3DVECTOR * const pv1,
	const float		fBlend);

static void RenderLogo(LPDIRECT3DDEVICE9 lpDev9);

/****************************************************************************
** Constants
****************************************************************************/
const static D3DVERTEXELEMENT9	c_pVertexElement[3] = {
	{ 0,  0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
	{ 0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
	D3DDECL_END()
};

const SVtx	c_pvCube[8] = {		// Vertices for a cube
	{ -1, -1, -1,  0, 0, 0 },
	{  1, -1, -1,  1, 0, 0 },
	{ -1, -1,  1,  0, 0, 1 },
	{  1, -1,  1,  1, 0, 1 },
	{ -1,  1, -1,  0, 1, 0 },
	{  1,  1, -1,  1, 1, 0 },
	{ -1,  1,  1,  0, 1, 1 },
	{  1,  1,  1,  1, 1, 1 }
};

const WORD	c_pwCube[12 * 3] = {	// Triangle-list indices for a cube
	0, 4, 5,  0, 5, 1,
	1, 5, 7,  1, 7, 3,
	3, 7, 6,  3, 6, 2,
	2, 6, 4,  2, 4, 0,
	4, 6, 7,  4, 7, 5,
	2, 0, 1,  2, 1, 3
};

const D3DVECTOR c_vUp	= { 0, 1, 0 };
const float		c_fCameraSpeed = 0.05f;	// Rate of motion for the camera (mouse/kb control)

// Animation keyframes for the 8 metaballs
const D3DVECTOR	c_pvMetaBall[METABALL_KEYFRAME_NUM][METABALL_NUM] = {
	{
		{ 0.5f, 0.5f, 0.5f},			// Big blob
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f}
	}, {
		{ 0.75f, 0.5f, 0.75f},			// Square
		{ 0.75f, 0.5f, 0.75f},
		{ 0.75f, 0.5f, 0.25f},
		{ 0.75f, 0.5f, 0.25f},
		{ 0.25f, 0.5f, 0.25f},
		{ 0.25f, 0.5f, 0.25f},
		{ 0.25f, 0.5f, 0.75f},
		{ 0.25f, 0.5f, 0.75f}
	}, {
		{ 0.75f, 0.25f, 0.75f},			// Cube
		{ 0.75f, 0.75f, 0.75f},
		{ 0.75f, 0.25f, 0.25f},
		{ 0.75f, 0.75f, 0.25f},
		{ 0.25f, 0.25f, 0.25f},
		{ 0.25f, 0.75f, 0.25f},
		{ 0.25f, 0.25f, 0.75f},
		{ 0.25f, 0.75f, 0.75f}
	}, {
		{ 0.5f, 0.5f, 0.8f},			// Circle
		{ 0.71f, 0.5f, 0.71f},
		{ 0.8f, 0.5f, 0.5f},
		{ 0.71f, 0.5f, 0.29f},
		{ 0.5f, 0.5f, 0.2f},
		{ 0.29f, 0.5f, 0.29f},
		{ 0.2f, 0.5f, 0.5f},
		{ 0.29f, 0.5f, 0.71f}
	}, {
		{ 0.5f, 0.2f, 0.8f},			// Spiral
		{ 0.71f, 0.3f, 0.71f},
		{ 0.8f, 0.4f, 0.5f},
		{ 0.71f, 0.5f, 0.29f},
		{ 0.5f, 0.6f, 0.2f},
		{ 0.29f, 0.7f, 0.29f},
		{ 0.2f, 0.8f, 0.5f},
		{ 0.29f, 0.9f, 0.71f}
	}, {
		{ 0.5f, 0.2f, 0.8f},			// Spiral
		{ 0.71f, 0.3f, 0.71f},
		{ 0.8f, 0.4f, 0.5f},
		{ 0.71f, 0.5f, 0.29f},
		{ 0.5f, 0.6f, 0.2f},
		{ 0.29f, 0.7f, 0.29f},
		{ 0.2f, 0.8f, 0.5f},
		{ 0.29f, 0.9f, 0.71f}
	}, {
		{ 0.3f, 0.8f, 0.5f},			// Face
		{ 0.7f, 0.8f, 0.5f},
		{ 0.8f, 0.15f, 0.5f},
		{ 0.65f, 0.11f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.07f, 0.5f},
		{ 0.35f, 0.11f, 0.5f},
		{ 0.2f, 0.15f, 0.5f}
	}, {
		{ 0.3f, 0.8f, 0.5f},			// Face
		{ 0.7f, 0.8f, 0.5f},
		{ 0.8f, 0.15f, 0.5f},
		{ 0.65f, 0.11f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.07f, 0.5f},
		{ 0.35f, 0.11f, 0.5f},
		{ 0.2f, 0.15f, 0.5f}
	}, {
		{ 0.5f, 0.5f, 0.5f},			// Big blob
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f},
		{ 0.5f, 0.5f, 0.5f}
	}
};

const float			c_fMbTxScale = 0.018f;		// Metaball scale factor


/****************************************************************************
** Globals
****************************************************************************/
static HWND g_hWnd;

static IDirect3DDevice9				*g_Dev;	/* Just a pointer to a device */

static DWORD						g_dwResX, g_dwResY;

/* Created resources */
static IDirect3DVertexShader9		*g_VsVxl;
static IDirect3DPixelShader9		*g_PsVxlHolo;
static IDirect3DPixelShader9		*g_PsVxlSolid;
static IDirect3DPixelShader9		*g_PsVxlLit1;
static IDirect3DPixelShader9		*g_PsVxlLit3;

static IDirect3DVertexDeclaration9	*g_VtxDecl;

static IDirect3DVolumeTexture9		*g_TxVolTest;	// Colour map
static IDirect3DVolumeTexture9		*g_TxVolTestA;	// Alpha "matter map"

static IDirect3DVolumeTexture9		*g_TxVolHeadA;	// Alpha "matter map"
static IDirect3DVolumeTexture9		*g_TxVolBunnyA;	// Alpha "matter map"

static IDirect3DVolumeTexture9		*g_TxVolMb;		// Metaball colour map
static IDirect3DVolumeTexture9		*g_TxVolMbA;	// Metaball alpha "matter map"

static IDirect3DTexture9			*g_TxLogo;		// PowerVR logo

static IDirect3DVertexBuffer9		*g_Vb;
static IDirect3DIndexBuffer9		*g_Ib;

static SCamera		g_sCamera;

static DWORD		g_dwFrame	= -2;
static DWORD		g_dwLoop	= -1;

// Each of these animation sequences will be made into a seperate AVI movie (probably)
static SAnimLoop	g_psAnimLoop[13] = {
	{ eHolo,	eMetaballs, 64,		1.0f,	FALSE,	0.0f },
	{ eSolid,	eMetaballs, 64,		0.5f,	FALSE,	0.0f },
	{ eLit1,	eMetaballs, 64,		0.5f,	FALSE,	0.0f },
	{ eLit3,	eMetaballs, 64,		0.5f,	FALSE,	0.0f },
	{ eLit3,	eMetaballs, 64,		0.5f,	TRUE,	0.0f },				// Animate the threshold value
	{ eLit3,	eHead,		128,	0.5f,	TRUE,	D3DX_PI },			// Animate the threshold value
	{ eSolid,	eMetaballs, 64,		0.5f,	TRUE,	0.0f },				// Animate the threshold value
	{ eSolid,	eHead,		128,	0.5f,	TRUE,	D3DX_PI },			// Animate the threshold value
	{ eLit3,	eBunny,		255,	0.05f,	FALSE,	D3DX_PI * 0.5f },	// Animation is simple rotation
	{ eSolid,	eHead,		128,	0.1f,	FALSE,	D3DX_PI },			// Animation is simple rotation
	{ eSolid,	eBunny,		255,	0.05f,	FALSE,	D3DX_PI * 0.5f },	// Animation is simple rotation
	{ eHolo,	eHead,		128,	4.0f,	FALSE,	D3DX_PI },			// Animation is simple rotation
	{ eHolo,	eBunny,		128,	4.0f,	FALSE,	D3DX_PI * 0.5f }	// Animation is simple rotation
};

/****************************************************************************
** D3DShell Functions
****************************************************************************/


/****************************************************************************
** InitApplication() is called by D3DShell to enable user to initialise	   **
** his/her application													   **
****************************************************************************/
void InitApplication(HINSTANCE hInstance, HWND hWindow, char *pszCommandLine)
{
	int i;

	g_hWnd = hWindow;

	/* Check for memory leaks (very nifty, this)
	** also checks for writing into free'd memory */
	_CrtSetDbgFlag(_CRTDBG_DELAY_FREE_MEM_DF | _CRTDBG_LEAK_CHECK_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG));

	/* You can use D3DShellSetPreferences(...) to set preferences for your application. 
	   You can specify a name, pass a menu, an accelerator table, an application icon 
	   and specify default rendering variables that will be used with your program */
	D3DShellSetPreferences(
		"Voxel Rendering",
		LoadMenu(hInstance, "MENU"),
		LoadAccelerators(hInstance, "ACCEL"),
		LoadIcon(hInstance, "ICON"),
		DEFAULT_CLEAR_ON | DEFAULT_TRIPLE_BUFFER);

	/*
		...and the mouse
	*/
	D3DTMouseInit(hInstance, hWindow);

	/*
		Initialise the camera
	*/
	g_sCamera.vFrom.x = 0;
	g_sCamera.vFrom.y = 2;
	g_sCamera.vFrom.z = -4;

	g_sCamera.fX = atan2f(g_sCamera.vFrom.y, -g_sCamera.vFrom.z);

	/*
		Specify a movie number
	*/
	if(strnicmp(pszCommandLine, "-clip=", 6) == 0)
	{
		i = atoi(pszCommandLine + 6);

		if(i >= 0 && i < CLIP_NUM)
			g_dwLoop = i - 1;
	}
}


/****************************************************************************
** QuitApplication() is called by D3DShell to enable user to release      **
** any memory before quitting the program.								   **
****************************************************************************/
void QuitApplication()
{
	/* Release any memory or instances allocated in InitApplication() */

	/*
		Shutdown Print3D
	*/
	D3DTPrint3DDeleteAllWindows();

	/*
		...and the mouse
	*/
	D3DTMouseShutdown();
}


/****************************************************************************
** UserWindowProc(...) is the application's window messages handler.
** From that function you can process menu inputs, keystrokes, timers, etc...
** When processing keystrokes, DO NOT process ESCAPE key 
** (VK_ESCAPE), as it is already used by D3DShell.
****************************************************************************/
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* You can process normal window messages from that function (WM_COMMAND
	   to retrieve menu inputs, WM_KEYDOWN to retrieve keystrokes, etc...) */
#ifdef ENABLE_USER_CONTROL
	switch(message) {
	case WM_COMMAND:
		switch(LOWORD(wParam)) {
		case MENU_SHADER_RELOAD:
			LoadShaders();
			break;

		case MENU_RENDERTYPE_HOLO:
			g_psAnimLoop[g_dwLoop].eRenderType = eHolo;
			break;
		case MENU_RENDERTYPE_SOLID:
			g_psAnimLoop[g_dwLoop].eRenderType = eSolid;
			break;
		case MENU_RENDERTYPE_LIT1:
			g_psAnimLoop[g_dwLoop].eRenderType = eLit1;
			break;
		case MENU_RENDERTYPE_LIT3:
			g_psAnimLoop[g_dwLoop].eRenderType = eLit3;
			break;

		case MENU_RENDEROB_TEST:
			g_psAnimLoop[g_dwLoop].eRenderOb = eTest;
			break;
		case MENU_RENDEROB_METABALLS:
			g_psAnimLoop[g_dwLoop].eRenderOb = eMetaballs;
			break;
		case MENU_RENDEROB_HEAD:
			g_psAnimLoop[g_dwLoop].eRenderOb = eHead;
			break;
		case MENU_RENDEROB_BUNNY:
			g_psAnimLoop[g_dwLoop].eRenderOb = eBunny;
			break;
		}
		break;
	}
#endif // ENABLE_USER_CONTROL
}


/****************************************************************************
** RenderScene(...) is the main rendering function. It is called by D3DShell
** for every frame.
** This function should contain a single BeginScene()/EndScene() pair containing
** the rendering functions to call (DrawPrimitive, SetRenderState, etc...)
****************************************************************************/
BOOL RenderScene(LPDIRECT3DDEVICE9WRAPPED lpDev9)
{
	D3DMATRIX	mTmp, mWorld, mView, mProj;
	D3DXVECTOR4	vTmp;
	int			pnRep[4];
	D3DXVECTOR3	pvMbPos[METABALL_NUM];
	float		fThreshold;

	/*
		Handle animation; this is set up for movie recording
	*/
	g_dwFrame++;
	if(g_dwFrame >= METABALL_FRAME_CNT)
	{
		g_dwFrame = 0;
		g_dwLoop++;

		if(g_dwLoop >= CLIP_NUM)
			return FALSE;	// Quit when nothing more to put into a movie

		/*
			In case they're not animated, preload the volume texture
		*/
		D3DXFillVolumeTexture(g_TxVolMb, FillTxVolMb, (void*)c_pvMetaBall[4]);
		D3DXFillVolumeTexture(g_TxVolMbA, FillTxVolMbA, (void*)c_pvMetaBall[4]);

	}

	// Decide on a threshold value for matter-detection
	if(g_psAnimLoop[g_dwLoop].bAnimateThresholdValue)
	{
		// Animate the threshold from, oh, let's say 0.1 to 0.7
		fThreshold = 0.4f + 0.3f * sinf(2.0f * (2.0f * D3DX_PI * (float)(g_dwFrame+50) / (float)METABALL_FRAME_CNT));
	}
	else
	{
		fThreshold = g_psAnimLoop[g_dwLoop].fThreshold;
	}

	/*
		Update metaball animation
	*/
	if(g_psAnimLoop[g_dwLoop].eRenderOb == eMetaballs && !g_psAnimLoop[g_dwLoop].bAnimateThresholdValue)
	{
		int		nAnimFrame;
		float	fBlend;

		nAnimFrame	= g_dwFrame / ANIM_FPF;
		fBlend		= (float)(g_dwFrame % ANIM_FPF) / (float)ANIM_FPF;

		CalcMbPos(pvMbPos, c_pvMetaBall[nAnimFrame], c_pvMetaBall[nAnimFrame+1], fBlend);

		/*
			Update texture
		*/
		D3DXFillVolumeTexture(g_TxVolMb, FillTxVolMb, pvMbPos);
		D3DXFillVolumeTexture(g_TxVolMbA, FillTxVolMbA, pvMbPos);
	}

#ifdef ENABLE_USER_CONTROL
	/*
		Camera motion
	*/
	UserInput();
#endif // ENABLE_USER_CONTROL

	/*
		Generate matrices
	*/

	// Rotate the object
	D3DXMatrixRotationX((D3DXMATRIX*)&mWorld, g_psAnimLoop[g_dwLoop].fRotX);
	D3DXMatrixRotationY((D3DXMATRIX*)&mTmp, 2.0f * D3DX_PI * (float)(g_dwFrame+50) / (float)METABALL_FRAME_CNT);
	D3DXMatrixMultiply((D3DXMATRIX*)&mWorld, (D3DXMATRIX*)&mWorld, (D3DXMATRIX*)&mTmp);

	// View & projection matrices
	D3DXMatrixLookAtLH((D3DXMATRIX*)&mView, (D3DXVECTOR3*)&g_sCamera.vFrom, (D3DXVECTOR3*)&g_sCamera.vTo, (D3DXVECTOR3*)&c_vUp);
	D3DXMatrixMultiply((D3DXMATRIX*)&mTmp, (D3DXMATRIX*)&mWorld, (D3DXMATRIX*)&mView);
	D3DXMatrixPerspectiveFovLH((D3DXMATRIX*)&mProj, CAM_FOV_Y, CAM_ASPECT, CAM_NEAR, CAM_FAR);
	D3DXMatrixMultiplyTranspose((D3DXMATRIX*)&mTmp, (D3DXMATRIX*)&mTmp, (D3DXMATRIX*)&mProj);

	/*
		Begin Scene
	*/
	lpDev9->BeginScene();

	lpDev9->SetVertexDeclaration(g_VtxDecl);
	lpDev9->SetVertexShader(g_VsVxl);

	switch(g_psAnimLoop[g_dwLoop].eRenderType) {
		case eHolo:
			lpDev9->SetPixelShader(g_PsVxlHolo);
			break;
		case eSolid:
			lpDev9->SetPixelShader(g_PsVxlSolid);
			break;
		case eLit1:
			lpDev9->SetPixelShader(g_PsVxlLit1);
			break;
		case eLit3:
			lpDev9->SetPixelShader(g_PsVxlLit3);
			break;
		default:
			_ASSERT(0);
	}

	lpDev9->SetSamplerState(0, D3DSAMP_MAGFILTER, FILTERING);
	lpDev9->SetSamplerState(0, D3DSAMP_MINFILTER, FILTERING);
	lpDev9->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	lpDev9->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	lpDev9->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	lpDev9->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	lpDev9->SetSamplerState(1, D3DSAMP_MAGFILTER, FILTERING);
	lpDev9->SetSamplerState(1, D3DSAMP_MINFILTER, FILTERING);
	lpDev9->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	lpDev9->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	lpDev9->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	lpDev9->SetSamplerState(1, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	switch(g_psAnimLoop[g_dwLoop].eRenderOb) {
		case eTest:
			lpDev9->SetTexture(0, g_TxVolTestA);
			lpDev9->SetTexture(1, g_TxVolTest);
			break;
		case eMetaballs:
			lpDev9->SetTexture(0, g_TxVolMbA);
			lpDev9->SetTexture(1, g_TxVolMb);
			break;
		case eHead:
			lpDev9->SetTexture(0, g_TxVolHeadA);
			lpDev9->SetTexture(1, g_TxVolMb);
			break;
		case eBunny:
			lpDev9->SetTexture(0, g_TxVolBunnyA);
			lpDev9->SetTexture(1, g_TxVolMb);
			break;
		default:
			_ASSERT(0);
	}

	lpDev9->SetStreamSource(0, g_Vb, 0, sizeof(SVtx));
	lpDev9->SetIndices(g_Ib);

	/*
		VS constants
	*/

	// World.View.Proj matrix
	lpDev9->SetVertexShaderConstantF(0, (float*)&mTmp, 4);

	// Camera in model space
	D3DXMatrixInverse((D3DXMATRIX*)&mTmp, NULL, (D3DXMATRIX*)&mWorld);
	D3DXVec3Transform(&vTmp, (D3DXVECTOR3*)&g_sCamera.vFrom, (D3DXMATRIX*)&mTmp);
	lpDev9->SetVertexShaderConstantF(4, (float*)&vTmp, 1);

	// Length of step vector
	vTmp.x = 1.732f / (float)(g_psAnimLoop[g_dwLoop].dwNumSteps >> NUM_STEPS_SHIFT);	// sqrt(3) * 1/NUM_STEPS
	lpDev9->SetVertexShaderConstantF(5, (float*)&vTmp, 1);

	/*
		PS constants
	*/

	// Brightness scale, or length of step vector; and threshold value for matter detection
	if(g_psAnimLoop[g_dwLoop].eRenderType == eHolo)
	{
		vTmp.x *= g_psAnimLoop[g_dwLoop].fBrightnessScale;	// Scale up the resulting brightness a tad
	}

	vTmp.y = fThreshold;									// Threshold value for matter-detection
	lpDev9->SetPixelShaderConstantF(1, (float*)&vTmp, 1);

	// Loop lotsa times, the loop will most likely hit a BREAK before completing.
	pnRep[0] = g_psAnimLoop[g_dwLoop].dwNumSteps >> NUM_STEPS_SHIFT;
	pnRep[1] = 0;
	pnRep[2] = 1;
	pnRep[3] = 0;
	lpDev9->SetPixelShaderConstantI(0, pnRep, 1);

	/*
		Render: voxel object (a cube)
	*/
	lpDev9->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 8, 0, 12);

	/*
		Render text
	*/
	lpDev9->SetPixelShader(NULL);
	lpDev9->SetVertexShader(NULL);

	D3DTPrint3D(1, 0.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "%03d/%d", g_dwFrame, METABALL_FRAME_CNT);

	switch(g_psAnimLoop[g_dwLoop].eRenderOb) {
		case eTest:
			D3DTPrint3D(1, 4.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Ob: Test");
			break;
		case eMetaballs:
			D3DTPrint3D(1, 4.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Ob: Metaballs");
			break;
		case eHead:
			D3DTPrint3D(1, 4.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Ob: Head");
			break;
		case eBunny:
			D3DTPrint3D(1, 4.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Ob: Bunny");
			break;
	}

	switch(g_psAnimLoop[g_dwLoop].eRenderType) {
		case eHolo:
			D3DTPrint3D(1, 8.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Method: Holo");
			break;
		case eSolid:
			D3DTPrint3D(1, 8.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Method: Solid");
			break;
		case eLit1:
			D3DTPrint3D(1, 8.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Method: Lit1");
			break;
		case eLit3:
			D3DTPrint3D(1, 8.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Method: lit3");
			break;
	}

	D3DTPrint3D(1, 12.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255),
		g_psAnimLoop[g_dwLoop].eRenderType == eHolo		? "Brightness %.3f"							: "Threshold %.3f",
		g_psAnimLoop[g_dwLoop].eRenderType == eHolo		? g_psAnimLoop[g_dwLoop].fBrightnessScale	: fThreshold);
	D3DTPrint3D(1, 16.5f, 0.7f, D3DCOLOR_RGBA(255, 255, 255, 255), "Max steps %d", pnRep[0]);

	RenderLogo(lpDev9);

	/*
		End Scene
	*/
    lpDev9->EndScene();

	/* The function should ALWAYS return TRUE if the rendering was successful.
	   If D3DShell receives FALSE from this function, then rendering will be
	   stopped and the application will be terminated */
	return TRUE;
}
	

/****************************************************************************
** InitView() is called by D3DShell each time a rendering variable is changed
** in the Shell menu (Z-Buffer On/Off, resolution change, buffering mode...)
** In this function one should initialise all variables that are dependant on
** general rendering variables (screen mode, 3D device, etc...)
****************************************************************************/
BOOL InitView(
	LPDIRECT3D9 lpD3D9, LPDIRECT3DDEVICE9WRAPPED lpDev9,
	DWORD dwWidth, DWORD dwHeight)
{
	HRESULT hRet;
	SVtx	*pvData;
	WORD	*pwData;

	/* From this function you can create your rendering variables (Lights, 
	   Materials, Textures, etc... */
	g_Dev = lpDev9;
	g_dwResX = dwWidth;
	g_dwResY = dwHeight;

	/*
		Load the vertex & pixel shaders
	*/
	if(!LoadShaders())
		return FALSE;

	/*
		Create: Vertex declaration
	*/
	hRet = lpDev9->CreateVertexDeclaration(c_pVertexElement, &g_VtxDecl);
	_ASSERT(hRet == D3D_OK);

	/*
		Create: Vertex buffer
	*/
	hRet = lpDev9->CreateVertexBuffer(8 * sizeof(SVtx), D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &g_Vb, NULL);
	_ASSERT(hRet == D3D_OK);

	hRet = g_Vb->Lock(0, 0, (void**)&pvData, 0);
	_ASSERT(hRet == D3D_OK);

	memcpy(pvData, c_pvCube, 8 * sizeof(SVtx));

	hRet = g_Vb->Unlock();
	_ASSERT(hRet == D3D_OK);

	/*
		Create: Index buffer
	*/
	hRet = lpDev9->CreateIndexBuffer(12 * 3 * sizeof(WORD), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_Ib, NULL);
	_ASSERT(hRet == D3D_OK);

	hRet = g_Ib->Lock(0, 0, (void**)&pwData, 0);
	_ASSERT(hRet == D3D_OK);

	memcpy(pwData, c_pwCube, 12 * 3 * sizeof(WORD));

	hRet = g_Ib->Unlock();
	_ASSERT(hRet == D3D_OK);

	/*
		Create: Textures
	*/
	hRet = D3DXCreateVolumeTextureFromResource(lpDev9, NULL, FILE_TX_TEST, &g_TxVolTest);
	_ASSERT(hRet == D3D_OK);

	hRet = D3DXCreateVolumeTextureFromResource(lpDev9, NULL, FILE_TX_TEST_A, &g_TxVolTestA);
	_ASSERT(hRet == D3D_OK);

	hRet = D3DXCreateVolumeTextureFromResource(lpDev9, NULL, FILE_TX_HEAD_A, &g_TxVolHeadA);
	_ASSERT(hRet == D3D_OK);

	hRet = D3DXCreateVolumeTextureFromResource(lpDev9, NULL, FILE_TX_BUNNY_A, &g_TxVolBunnyA);
	_ASSERT(hRet == D3D_OK);

	hRet = D3DXCreateTextureFromResource(lpDev9, NULL, FILE_TX_LOGO, &g_TxLogo);
	_ASSERT(hRet == D3D_OK);

	/*
		Create: Metaball textures
	*/
	hRet = D3DXCreateVolumeTexture(lpDev9, TX_SIZE_METABALL, TX_SIZE_METABALL, TX_SIZE_METABALL, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &g_TxVolMb);
	_ASSERT(hRet == D3D_OK);

	hRet = D3DXCreateVolumeTexture(lpDev9, TX_SIZE_METABALL, TX_SIZE_METABALL, TX_SIZE_METABALL, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8, D3DPOOL_DEFAULT, &g_TxVolMbA);
	_ASSERT(hRet == D3D_OK);

	/*
		Enable dithering (might as well)
	*/
	lpDev9->SetRenderState(D3DRS_DITHERENABLE, TRUE);

	/*
		Initialise 3D text
	*/
	if(!D3DTPrint3DSetTextures(lpDev9, dwWidth, dwHeight))
		return FALSE;

	/* The function should ALWAYS return TRUE if the initialisation was successful.
	   If D3DShell receives FALSE from this function, then rendering will be
	   stopped and the application will be terminated */
	return TRUE;
}


/****************************************************************************
** ReleaseView(...) is called by D3DShell each time a rendering variable is
** changed. It is the direct companion to InitView(...), as its purpose is to
** release or destroy any variables or processes allocated in InitView.
** NOTE : Textures created with the D3DShellLoadBMP(...) function do *NOT* need
** to be released, as it is already taken care of by D3DShell.
****************************************************************************/
void ReleaseView()
{
	/* Release any interfaces or variables created in InitView() */
	
	/* shutdown Print3D */
	D3DTPrint3DReleaseTextures();

	RELEASE(g_Ib);
	RELEASE(g_Vb);

	RELEASE(g_VsVxl);
	RELEASE(g_PsVxlHolo);
	RELEASE(g_PsVxlSolid);
	RELEASE(g_PsVxlLit1);
	RELEASE(g_PsVxlLit3);

	RELEASE(g_VtxDecl);

	RELEASE(g_TxVolTest);
	RELEASE(g_TxVolTestA);
	RELEASE(g_TxVolHeadA);
	RELEASE(g_TxVolBunnyA);

	RELEASE(g_TxVolMb);
	RELEASE(g_TxVolMbA);

	RELEASE(g_TxLogo);
}


/****************************************************************************
** Application Functions
****************************************************************************/

static BOOL LoadVertexShader(
	const char * const pszName,
	IDirect3DVertexShader9	** ppi)
{
	ID3DXBuffer	*piBuf, *piErr;
	HRESULT		hRet;

	hRet = D3DXAssembleShaderFromResource(NULL, pszName, NULL, NULL, D3DXSHADER_DEBUG, &piBuf, &piErr);
	if(hRet != D3D_OK)
	{
		MessageBox(g_hWnd, "Could not load Vertex Shader. Try running on the reference rasteriser (command line option \"-RefDevice\") or on hardware supporting VS_3_0", "Error", MB_OK);
		return FALSE;
	}

	hRet = g_Dev->CreateVertexShader((DWORD*)piBuf->GetBufferPointer(), ppi);
	if(hRet != D3D_OK)
	{
		MessageBox(g_hWnd, "Could not load Vertex Shader. Try running on the reference rasteriser (command line option \"-RefDevice\") or on hardware supporting VS_3_0", "Error", MB_OK);
		return FALSE;
	}

	RELEASE(piBuf);
	RELEASE(piErr);
	return TRUE;
}

static BOOL LoadPixelShader(
	const char * const pszName,
	IDirect3DPixelShader9	** ppi)
{
	ID3DXBuffer	*piBuf, *piErr;
	HRESULT		hRet;

	hRet = D3DXAssembleShaderFromResource(NULL, pszName, NULL, NULL, D3DXSHADER_DEBUG, &piBuf, &piErr);
	if(hRet != D3D_OK)
	{
		MessageBox(g_hWnd, "Could not load Pixel Shader. Try running on the reference rasteriser (command line option \"-RefDevice\") or on hardware supporting PS_3_0", "Error", MB_OK);
		return FALSE;
	}

	hRet = g_Dev->CreatePixelShader((DWORD*)piBuf->GetBufferPointer(), ppi);
	if(hRet != D3D_OK)
	{
		MessageBox(g_hWnd, "Could not load Pixel Shader. Try running on the reference rasteriser (command line option \"-RefDevice\") or on hardware supporting PS_3_0", "Error", MB_OK);
		return FALSE;
	}

	RELEASE(piBuf);
	RELEASE(piErr);
	return TRUE;
}

static BOOL LoadShaders()
{
	RELEASE(g_VsVxl);
	RELEASE(g_PsVxlHolo);
	RELEASE(g_PsVxlSolid);
	RELEASE(g_PsVxlLit1);
	RELEASE(g_PsVxlLit3);

	if(!LoadVertexShader(FILE_VS, &g_VsVxl))
		return FALSE;

	if(!LoadPixelShader(FILE_PS_HOLO, &g_PsVxlHolo))
		return FALSE;

	if(!LoadPixelShader(FILE_PS_SOLID, &g_PsVxlSolid))
		return FALSE;

	if(!LoadPixelShader(FILE_PS_LIT1, &g_PsVxlLit1))
		return FALSE;

	if(!LoadPixelShader(FILE_PS_LIT3, &g_PsVxlLit3))
		return FALSE;

	return TRUE;
}

#ifdef ENABLE_USER_CONTROL
/*******************************************************************************
 * Function Name  : UserInput
 * Returns        :
 * Global Used    :
 * Description    : Read the keyboard on real time.
 *******************************************************************************/
static void UserInput(void)
{
	D3DXMATRIX	mTrans, mTmp;
	D3DXVECTOR3	v, s;
	int			nMouseX, nMouseY, nMouseButtons;
	float		fSpeed;

	fSpeed = (GetKeyState(VK_SHIFT)>>8) ? c_fCameraSpeed * 4 : c_fCameraSpeed;

	// Check mouse input
	D3DTMouseQuery(&nMouseX, &nMouseY, &nMouseButtons);
	if(nMouseButtons)
	{
		g_sCamera.fX += 0.01f * nMouseY;
		g_sCamera.fY += 0.01f * nMouseX;
	}

	// Update camera position
	D3DXMatrixRotationX(&mTrans, g_sCamera.fX);

	D3DXMatrixRotationY(&mTmp, g_sCamera.fY);
	D3DXMatrixMultiply(&mTrans, &mTrans, &mTmp);

	v.x = mTrans._31;	// transform (0,0,1)
	v.y = mTrans._32;
	v.z = mTrans._33;

	D3DXVec3Cross(&s, (D3DXVECTOR3*)&c_vUp, &v);

	if (GetKeyState('W')>>8)
	{
	    g_sCamera.vFrom.x += v.x * fSpeed;
	    g_sCamera.vFrom.y += v.y * fSpeed;
	    g_sCamera.vFrom.z += v.z * fSpeed;
	}

	if (GetKeyState('S')>>8)
	{
	    g_sCamera.vFrom.x -= v.x * fSpeed;
	    g_sCamera.vFrom.y -= v.y * fSpeed;
	    g_sCamera.vFrom.z -= v.z * fSpeed;
	}

	if (GetKeyState('A')>>8)
	{
	    g_sCamera.vFrom.x -= s.x * fSpeed;
	    g_sCamera.vFrom.y -= s.y * fSpeed;
	    g_sCamera.vFrom.z -= s.z * fSpeed;
	}

	if (GetKeyState('D')>>8)
	{
	    g_sCamera.vFrom.x += s.x * fSpeed;
	    g_sCamera.vFrom.y += s.y * fSpeed;
	    g_sCamera.vFrom.z += s.z * fSpeed;
	}

	if (GetKeyState(' ')>>8)
	{
	    g_sCamera.vFrom.x += c_vUp.x * fSpeed;
	    g_sCamera.vFrom.y += c_vUp.y * fSpeed;
	    g_sCamera.vFrom.z += c_vUp.z * fSpeed;
	}

	if (GetKeyState('C')>>8)
	{
	    g_sCamera.vFrom.x -= c_vUp.x * fSpeed;
	    g_sCamera.vFrom.y -= c_vUp.y * fSpeed;
	    g_sCamera.vFrom.z -= c_vUp.z * fSpeed;
	}

	g_sCamera.vTo.x = g_sCamera.vFrom.x + v.x;
	g_sCamera.vTo.y = g_sCamera.vFrom.y + v.y;
	g_sCamera.vTo.z = g_sCamera.vFrom.z + v.z;
}
#endif // ENABLE_USER_CONTROL

// D3DXFillVolumeTexture() callback: set colour to coordinate (useless but there you go)
VOID WINAPI FillTxVolMb(D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData)
{
	*pOut = D3DXVECTOR4(pTexCoord->x, pTexCoord->y, pTexCoord->z, 0);
}

// D3DXFillVolumeTexture() callback: fill alpha channel with metaball powers
VOID WINAPI FillTxVolMbA(D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData)
{
	D3DXVECTOR3	v;
	float		f, fOut;
	int			i;
	D3DXVECTOR3	*pMbPos;

	f = 0.5f / (float)(TX_SIZE_METABALL-1);
	if(
		pTexCoord->x <= f || pTexCoord->x >= (1.0f - f) ||
		pTexCoord->y <= f || pTexCoord->y >= (1.0f - f) ||
		pTexCoord->z <= f || pTexCoord->z >= (1.0f - f) )
	{
		// Leave the edge voxels empty
		*pOut = D3DXVECTOR4(0, 0, 0, 0);
	}
	else
	{
		pMbPos = (D3DXVECTOR3*)pData;

		fOut = 0;
		for(i = 0; i < METABALL_NUM; ++i)
		{
			v = *pTexCoord - pMbPos[i];
			f = c_fMbTxScale / D3DXVec3Length(&v);
			fOut += f;
		}

		*pOut = D3DXVECTOR4(0, 0, 0, fOut);
	}
}

// Calc current metaball positions by blending between two keyframes
static void CalcMbPos(
	D3DVECTOR		* const pvOut,
	const D3DVECTOR * const pv0,
	const D3DVECTOR * const pv1,
	const float		fBlend)
{
	int i;

	for(i = 0; i < METABALL_NUM; ++i)
	{
		pvOut[i].x = pv0[i].x + fBlend * (pv1[i].x - pv0[i].x);
		pvOut[i].y = pv0[i].y + fBlend * (pv1[i].y - pv0[i].y);
		pvOut[i].z = pv0[i].z + fBlend * (pv1[i].z - pv0[i].z);
	}
}

/*******************************************************************************
 * Function Name  : RenderLogo
 * Inputs		  : lpDev9
 * Returns        : Nothing
 * Global Used    : 
 * Description    : 
 *******************************************************************************/
static void RenderLogo(LPDIRECT3DDEVICE9 lpDev9)
{
#define LOGO_WIDTH	89.0f
#define LOGO_HEIGHT	60.0f
	HRESULT			hres;
	struct XYZWUVVERTEX {
		float x, y, z, w;
		float tu, tv;
	} QuadVertices[4];
	float			fu0, fv0, fu1, fv1;

	/* Compute UVs to use */
	fu0 = 1.0f/(2.0f*128.0f);
	fv0 = 1.0f/(2.0f*64.0f);
	fu1 = (89.0f/128.0f) + fu0;
	fv1 = (60.0f/64.0f) + fv0;

	/* Set quad vertices */
	QuadVertices[0].x =  (float)g_dwResX-LOGO_WIDTH;
	QuadVertices[0].y =  (float)g_dwResY-LOGO_HEIGHT;
	QuadVertices[0].z =  0.0f;
	QuadVertices[0].w =  1.0f;
	QuadVertices[0].tu = fu0;
	QuadVertices[0].tv = fv0;

	QuadVertices[1].x =  (float)g_dwResX;
	QuadVertices[1].y =  (float)g_dwResY-LOGO_HEIGHT;
	QuadVertices[1].z =  0.0f;
	QuadVertices[1].w =  1.0f;
	QuadVertices[1].tu = fu1;
	QuadVertices[1].tv = fv0;

	QuadVertices[2].x =  (float)g_dwResX-LOGO_WIDTH;
	QuadVertices[2].y =  (float)g_dwResY;
	QuadVertices[2].z =  0.0f;
	QuadVertices[2].w =  1.0f;
	QuadVertices[2].tu = fu0;
	QuadVertices[2].tv = fv1;

	QuadVertices[3].x =  (float)g_dwResX;
	QuadVertices[3].y =  (float)g_dwResY;
	QuadVertices[3].z =  0.0f;
	QuadVertices[3].w =  1.0f;
	QuadVertices[3].tu = fu1;
	QuadVertices[3].tv = fv1;

	/* Depth/Stencil state */
//	lpDev9->SetRenderState(D3DRS_STENCILENABLE, FALSE);
//	lpDev9->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);

	/* Alpha blending disabled */
	lpDev9->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	/* No vertex shader */
	lpDev9->SetVertexShader(NULL);

	/* Set FVF */
	lpDev9->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);

	/* No pixel shader */
	lpDev9->SetPixelShader(NULL);

	/* TSS */
	lpDev9->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	lpDev9->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);

	/* Set texture */
	lpDev9->SetTexture(0, g_TxLogo);


	/* Draw particle */
	hres = lpDev9->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, QuadVertices, sizeof(XYZWUVVERTEX));
	if (hres!=D3D_OK)
	{
		OutputDebugString("DrawPrimitiveUP() failed in RenderScreenAlignedQuad()\n");
	}
}

/*****************************************************************************
 End of file (D3DVoxel.cpp)
*****************************************************************************/
