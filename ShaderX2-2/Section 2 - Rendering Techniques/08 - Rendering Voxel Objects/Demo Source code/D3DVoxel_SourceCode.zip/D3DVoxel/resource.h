//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by D3DVoxel.rc
//
#define IDI_ICON1                       101
#define ID_OPTIONS_TOGGLERENDERTYPE     104
#define RC_VSH_VOXEL                    107
#define IDB_BITMAP1                     117
#define MENU_PAGE_NEXT                  40001
#define MENU_PAGE_PREV                  40002
#define MENU_T_HELP                     40003
#define MENU_SHADER_RELOAD              40004
#define ID_ACCELERATOR40005             40005
#define MENU_T_RENDER                   40005
#define MENU_RENDERTYPE_HOLO            40007
#define MENU_RENDERTYPE_LIT1            40008
#define MENU_RENDERTYPE_LIT3            40009
#define MENU_RENDERTYPE_SOLID           40010
#define MENU_RENDEROB_HEAD              40011
#define MENU_RENDEROB_BUNNY             40012
#define MENU_RENDEROB_TEST              40013
#define MENU_RENDEROB_METABALLS         40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
